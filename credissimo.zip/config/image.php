<?php

return [
    'driver' => 'gd',
    'sizes' => [
        'small' => ['150', '150'],
        'med' => ['350', '350'],
        'large' => ['750', '750'],
    ],
];
