<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>
            <span>Products</span>
            <a style="" href="<?php echo e(route('product.create')); ?>" class="btn btn-primary float-right">
                Create Product
            </a>
        </h1>
        <?php echo $dataGrid->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>