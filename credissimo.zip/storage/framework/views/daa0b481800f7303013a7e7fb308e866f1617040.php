<?php echo Form::file('file','Images',['class' => 'product-image-element form-control','data-token' => csrf_token()]); ?>



<div class="product-image-list">

    <?php if(isset($product) && count($product->images()->get()->count()) > 0): ?>
        <?php $__currentLoopData = $product->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $class = ($image->is_main_image == 1) ? "active" : ""; ?>
            <div class="image-preview">
                <div class="actual-image-thumbnail">
                    <img class="img-thumbnail img-tag img-responsive" src="<?php echo e(($image->path->smallUrl)); ?>"/>
                    <input type="hidden" name="image[<?php echo e($image->id); ?>][path]" value="<?php echo e($image->path->relativePath); ?>"/>
                    <?php if($image->is_main_image): ?>
                        <input type="hidden" class="is_main_image_hidden_field"
                               name="image[<?php echo e($image->id); ?>][is_main_image]" value="1"/>
                    <?php else: ?>
                        <input type="hidden" class="is_main_image_hidden_field"
                               name="image[<?php echo e($image->id); ?>][is_main_image]" value="0"/>
                    <?php endif; ?>
                </div>
                <div class="image-info">
                    <div class="image-title">
                        XYZ.jpg
                    </div>
                    <div class="actions">
                        <div class="action-buttons pull-right">

                            <button type="button"
                                    class="btn is_main_image_button <?php echo e($class); ?> selected-icon btn-xs btn-default"
                                    title="Select as Main Image">
                                <i class="fa fa-check"></i>
                            </button>
                            <button type="button" class="destroy-image btn btn-xs btn-default" title="Remove file">
                                <i class="fa fa-trash-o text-danger"></i>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->startPush('styles'); ?>
<style>

    .image-preview {
        position: relative;
        display: table;
        margin: 8px;
        border: 1px solid #ddd;
        box-shadow: 1px 1px 5px 0 #a2958a;
        padding: 6px;
        float: left;
        text-align: center;
    }

    .image-preview .actual-image-thumbnail {
        height: 170px;
    }

    .image-preview .image-info .active.selected-icon {
        color: #00dd00;
    }

    .image-preview .image-info .image-title {
        margin-bottom: 15px;
    }

    .image-preview .image-info {
        position: relative;
        height: 70px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    jQuery(document).ready(function () {


        jQuery(document).on('click', '.product-image-list .is_main_image_button', function (e) {
            e.preventDefault();
            //jQuery(this).toggleClass('active');

            //x = this;

            //var mainImageSrc = jQuery(this).parents('.image-preview:first').find('img').attr('src');
            //jQuery('.top-header img').attr('src', mainImageSrc);

            //console.info(mainImageSrc);

            jQuery('.product-image-list .is_main_image_button').removeClass('active');
            jQuery('.product-image-list .is_main_image_hidden_field').val(0);


            if (jQuery(this).hasClass('active')) {

                jQuery(this).removeClass('active');
                jQuery(this).parents('.image-preview:first').find('.is_main_image_hidden_field').val(0);
            } else {
                jQuery(this).addClass('active');
                jQuery(this).parents('.image-preview:first').find('.is_main_image_hidden_field').val(1);
            }

        });
        jQuery(document).on('click', '.product-image-list .image-preview .destroy-image', function (e) {


            var token = jQuery('.product-image-element').attr('data-token');
            var path = jQuery(e.target).parents('.image-preview:first').find('.img-tag').attr('src');
            var data = {_token: token, path: path};
            jQuery.ajax({
                url: '<?php echo e(URL::to("/product-image/delete")); ?>',
                data: data,
                type: 'post',
                success: function (response) {
                    if (response == 'success') {
                        jQuery(e.target).parents('.image-preview:first').remove();
                    }

                }
            })
        });
        jQuery('.product-image-element').change(function (e) {
            var files = e.target.files;

            if (files.length <= 0) {
                return;
            }

            var formData = new FormData();

            formData.append('_token', jQuery(e.target).attr('data-token'));
            for (var i = 0, file; file = files[i]; ++i) {
                formData.append('image', file);
            }

            var xhr = new XMLHttpRequest();
            xhr.open('POST', '<?php echo e(URL::to("/product-image/upload")); ?>', true);
            xhr.onload = function (e) {
                if (this.status == 200) {

                    jQuery('.product-image-list').append(this.response);
                    if (jQuery('.product-image-list .image-preview').length == 1) {
                        jQuery('.product-image-list .image-preview .is_main_image_button').trigger('click');
                    }
                }
            };

            xhr.send(formData);

            jQuery(".product-image-element").val('');
        });

    });
</script>
<?php $__env->stopPush(); ?>

