<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-xs-12">
	<div class="card-box product-detail-box">
	   <div class="row">
	       <div class="col-sm-4">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($image->is_main_image): ?>
                    <img src="<?php echo $image->path->medUrl; ?>" alt="Preview image">
                    <?php 
                        break;
                     ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	       </div>
	       <div class="col-sm-8">
	           <div class="product-right-info">
	               <h1><b><?php echo e($product->name); ?></b></h1>
	               <h3>
	                   <b>$ <?php echo e(number_format($product->price, 2, '.', '')); ?></b>
	                   <small class="text-muted m-l-10"><del>$62</del> </small>
	               </h3>
	               <span class="label label-default m-l-5">In Stock</span>
	               <hr/>
	               <h5 class="font-600">Product Description</h5>

	               <p class="text-muted"><?php echo $product->description; ?></p>
	               <div class="m-t-30">
	                   <button type="button" class="btn btn-danger waves-effect waves-light m-l-10">
	                     <span class="btn-label"><i class="fa fa-shopping-cart"></i>
	                   </span>Buy Now</button>
	               </div>
	           </div>
	       </div>
	   </div>
	   <!-- end row -->

	   <div class="row m-t-30">
	       <div class="col-xs-12">
	           <h4><b>Specifications:</b></h4>
	           <div class="table-responsive m-t-20">
	               <table class="table">
	                   <tbody>
	                   <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                       <tr>
	                           <td width="400"><?php echo e($attribute->name); ?></td>
	                           <td>
	                               <?php echo e($attribute->value); ?>

	                           </td>
	                       </tr>
	                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                   </tbody>
	               </table>
	           </div>
	       </div>
	   </div>


	</div> <!-- end card-box/Product detai box -->
	</div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>