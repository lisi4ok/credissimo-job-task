<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <h1>Edit Category</h1>
            <?php echo Form::bind($category , ['method' => 'put', 'action' => route('category.update', $category->id)]); ?>


            <?php echo $__env->make('category._fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::submit('Edit Category', ['disabled' => true, 'class' => 'btn category-save-button']); ?>

            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-default">Cancel</a>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>