<?php echo Form::text('name','Name'); ?>

<?php echo Form::text('identifier','Identifier'); ?>


<?php if(0): ?>
<?php echo Form::select('field_type','Field Type',['' => 'Please Select','TEXT' => 'Text','TEXTAREA' => 'Text Area','SELECT' => 'Dropdown'] ); ?>

<?php endif; ?>
<?php echo Form::select('field_type','Field Type',['' => 'Please Select','TEXT' => 'Text'] ); ?>


<?php echo Form::text('sort_order','Sort Order'); ?>

