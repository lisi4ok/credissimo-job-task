
<?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 

        echo '<pre>';
        var_dump($attribute->name);
        exit;

     ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo Form::text('sku', 'SKU'); ?>


<?php echo Form::text('price','Price'); ?>

