<table class="app-table-grid table table-striped table-responsive ">
    <tr class="table-dark">
        <?php $__currentLoopData = $dataGrid->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th>
                <?php if($column->sortable() && $dataGrid->desc($column->identifier())): ?>
                    <a href="<?php echo e($column->ascUrl()); ?>">
                        <?php echo e($column->label()); ?>

                        <i class="text-primary oi oi-arrow-bottom"></i>
                    </a>
                <?php elseif($column->sortable() && $dataGrid->asc($column->identifier())): ?>
                        <a href="<?php echo e($column->descUrl()); ?>">
                            <?php echo e($column->label()); ?>

                            <i class="text-primary oi oi-arrow-top"></i>
                        </a>
                <?php elseif($column->sortable() ): ?>
                    <a href="<?php echo e($column->descUrl()); ?>">
                        <?php echo e($column->label()); ?>

                        <i class="text-secondary oi oi-arrow-top"></i>
                    </a>
                <?php else: ?>
                    <?php echo e($column->label()); ?>


                <?php endif; ?>

            </th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>

    <?php $__currentLoopData = $dataGrid->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php $__currentLoopData = $dataGrid->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <?php if($column->type() == "link"): ?>
                        <?php echo $column->executeCallback($row); ?>

                    <?php else: ?>
                        <?php $identifier = $column->identifier() ?>
                        <?php echo e($row->$identifier); ?>

                    <?php endif; ?>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo $dataGrid->data->appends(Request::except('page'))->render('pagination::bootstrap-4'); ?>

