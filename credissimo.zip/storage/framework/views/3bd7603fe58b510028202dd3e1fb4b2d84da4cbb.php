<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="h1">
            Categories
            <a style="" href="<?php echo e(route('category.create')); ?>" class="btn btn-primary float-right">
            	Create Category
            </a>
        </div>
        <?php echo $dataGrid->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>