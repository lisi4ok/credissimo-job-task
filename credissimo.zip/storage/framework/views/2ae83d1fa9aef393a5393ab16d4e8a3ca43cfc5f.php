<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8">
        <h1>Edit Product</h1>
        <div class="row">
        <?php echo Form::bind($product, ['files' => true,'method' => 'PUT', 'action' => route('product.update', $product->id),'id' => 'product-save-form' ]); ?>

            <?php 
                $productCategories = $product->categories()
                ->get()->pluck('id')->toArray();
             ?>
            <?php echo $__env->make('product._fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <hr />
            <?php echo $__env->make('product.images', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <hr />
            <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label for="<?php echo e($attribute->identifier); ?>"><?php echo e($attribute->name); ?></label>
                    <input type="text" class="form-control" name="<?php echo e($attribute->identifier); ?>" id="<?php echo e($attribute->identifier); ?>" placeholder="<?php echo e($attribute->name); ?>" value="<?php echo e($attribute->value); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo Form::submit('Edit Product'); ?>

            <?php echo Form::button('Cancel',['class' => 'btn', 'onclick' => 'location="'.route('product.index').'"']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>