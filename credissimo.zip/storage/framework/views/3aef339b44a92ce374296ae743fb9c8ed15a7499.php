<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8">
            <h1>Edit Attribute</h1>
            <?php echo Form::bind($attribute, ['method' => 'PUT', 'action' => route('attribute.update', $attribute->id)]); ?>


            <?php echo $__env->make('attribute._fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::submit('Update Attribute'); ?>

            <?php echo Form::button('Cancel',['class' => 'btn', 'onclick' => 'location="'.route('attribute.index').'"']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>