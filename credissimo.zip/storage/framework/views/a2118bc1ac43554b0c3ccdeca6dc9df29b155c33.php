<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8">
        <h1>Create Product</h1>
        <div class="row">
            <?php echo Form::open(['files' => true,'action' => route('product.store'),'method' => 'post','id' => 'product-save-form']); ?>


            <?php echo $__env->make('product._fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <hr />
            <?php echo $__env->make('product.images', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <hr />
            <?php $__currentLoopData = $attirbutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo Form::text($attribute->identifier, $attribute->name); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo Form::submit('Create Product'); ?>

            <?php echo Form::button('Cancel',['class' => 'btn', 'onclick' => 'location="'.route('product.index').'"']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>