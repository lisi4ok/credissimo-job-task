<?php $__env->startSection('content'); ?>
    <h1>
        <span>Attributes</span>
        <a style="" href="<?php echo e(route('attribute.create')); ?>" class="btn btn-primary float-right">Create
            Attribute</a>
    </h1>

    <?php echo $dataGrid->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>