
<?php echo Form::text('name','Product Name'); ?>


<?php echo Form::text('slug','Product Slug'); ?>


    <?php if(!isset($productCategories)): ?>
	    <?php 
	    	$productCategories = [];
	     ?>
    <?php endif; ?>
    <?php echo Form::select("category_id[]", "Category", $categoryOptions,
        ['class' => 'form-control select2',
        'multiple' => 'true',
        'value' => $productCategories
        ]
    ); ?>


<?php echo Form::text('sku', 'SKU'); ?>


<?php echo Form::text('price','Price'); ?>


<?php echo Form::textarea('description', 'Description',[
    'class' => 'ckeditor', 'style' => 'width: 1147px; height: 259px; margin: 0px;'
]); ?>


<?php $__env->startPush('scripts'); ?>
<script>
jQuery(document).ready(function() {
   	jQuery('.select2').select2();
});
</script>
<?php $__env->stopPush(); ?>
