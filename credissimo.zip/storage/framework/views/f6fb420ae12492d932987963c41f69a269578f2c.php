<?php $__env->startSection('content'); ?>
<h1><?php echo e($category->name); ?></h1>
<div class="row">
    <?php if(count($category->products) <= 0): ?>
        <p>Sorry No Products Found</p>
    <?php else: ?>
        <ul class="cd-gallery">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('product.show', $product->slug)); ?>">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($image->is_main_image): ?>
                        <img src="<?php echo $image->path->smallUrl; ?>" alt="Preview image">
                        <?php 
                            break;
                         ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
                <div class="cd-item-info">
                    <b><a href="<?php echo e(route('product.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></b>
                    <em class="cd-price">$ <?php echo e(number_format($product->price, 2, '.', '')); ?></em>
                </div>
                <div class="cd-item-details">
                    <a href="#" class="pull-left add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                    <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="pull-right details">
                        <i class="fa fa-list-ul"></i>Details
                    </a>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>